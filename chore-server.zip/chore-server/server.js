// Set up
var express = require('express');
var app = express();
var mongoose = require('mongoose');
var bodyParser = require('body-parser');
var methodOverride = require('method-override');
var cors = require('cors');

// Configuration
mongoose.connect(process.env.MONGODB_URI || "mongodb://localhost:27017/choredb");

app.use(bodyParser.urlencoded({'extended': 'true'}));
app.use(bodyParser.json());
app.use(bodyParser.json({type: 'application/vnd.api+json'}));
app.use(methodOverride());
app.use(cors());

app.use(function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header('Access-Control-Allow-Methods', 'DELETE, POST, PUT');
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

// Model for chorelist
var Chore = mongoose.model('Chore', {
    choredesc: String,
    value: Number,
    complete: Boolean,

});

// Get all chore items
app.get('/api/choredb', function (req, res) {

    console.log("Listing chores at this time...");

    //use mongoose to get all chores in the database
    Chore.find(function (err, chores) {

        // if there is an error retrieving, send the error. nothing after res.send(err) will execute
        if (err) {
            res.send(err);
        }

        res.json(chores); // return all chores in JSON format
    });
});

// Create a chore Item
app.post('/api/choredb', function (req, res) {

    console.log("Creating chore item...");

    Chore.create({
        choredesc: req.body.choredesc,
        value: req.body.value,
        complete : req.body.complete,
        done: false
    }, function (err, chore) {
        if (err) {
            res.send(err);
        }

        // create and return all the chores
        Chore.find(function (err, chores) {
            if (err)
                res.send(err);
            res.json(chores);
        });
    });

});

// Update a chore Item
app.put('/api/choredb/:id', function (req, res) {
    const chore = {
        choredesc: req.body.choredesc,
        value: req.body.value,
        complete : req.body.complete,
    };
    console.log("Updating item - ", req.params.id);
    Chore.update({_id: req.params.id}, chore, function (err, raw) {
        if (err) {
            res.send(err);
        }
        res.send(raw);
    });
});


// Delete a chore Item
app.delete('/api/choredb/:id', function (req, res) {
    Chore.remove({
        _id: req.params.id
    }, function (err, chore) {
        if (err) {
            console.error("Error deleting chore ", err);
        }
        else {
            Chore.find(function (err, chores) {
                if (err) {
                    res.send(err);
                }
                else {
                    res.json(chores);
                }
            });
        }
    });
});


// Start app and listen on port 8080  
app.listen(process.env.PORT || 8080);
console.log("Chore server listening on port  - ", (process.env.PORT || 8080));